

window.addEventListener('DOMContentLoaded', function() {

  var theme = document.getElementById('theme');
  theme.content="#008CBA";


});
